function b(e){return e==null?"":typeof e=="object"?JSON.stringify(e):String(e)}function s(e){const t=b(e).replace(/"/g,'""');return/[",\n]/.test(t)?`"${t}"`:t}function f(e,o,t){const d=o.map(c=>s(c.header)).join(","),i=t.map(c=>o.map(u=>s(c[u.key])).join(",")).join(`
`),a=`${d}
${i}`,p=new Blob([a],{type:"text/csv;charset=utf-8;"}),n=document.createElement("a"),r=URL.createObjectURL(p);n.href=r,n.setAttribute("download",e.endsWith(".csv")?e:`${e}.csv`),document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(r)}export{f as e};
