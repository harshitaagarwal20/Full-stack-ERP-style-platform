import { Router } from "express";
import { createCustomerMaster, createEnquiryMaster, createMasterDataValue, createProductMaster, createSupplierMaster, deleteMasterDataValue, editProductMaster, importCustomerMaster, importProductMaster, importSupplierMaster, listEditableCategories, listMasterData, removeCustomerMaster, removeProductMaster, removeSupplierMaster } from "../controllers/masterDataController.js";
import { authMiddleware } from "../middleware/authMiddleware.js";
import { requirePermission } from "../middleware/permissionMiddleware.js";
import { validateBody } from "../middleware/validateMiddleware.js";
import { createCustomerMasterSchema, createEnquiryMasterSchema, createMasterDataValueSchema, createSupplierMasterSchema, importCustomerMasterSchema, importProductMasterSchema, importSupplierMasterSchema, productMasterSchema } from "../utils/validators.js";

const router = Router();

// Module access is configured by an admin on the Role Management screen:
// reads need VIEW, writes need FULL.
const masterData = requirePermission("master_data");
// The product master is its own module, so a role can be trusted with products
// without also being handed customers, suppliers and the dropdown lists.
const productMaster = requirePermission("product_master");

router.use(authMiddleware);
// Reading the master data is not an admin act: it is what fills the dropdowns on
// every form in the app — products on an order, company names on an enquiry,
// units everywhere. Gating this on the master_data module left any role without
// it staring at empty pickers, because the client falls back to its built-in
// defaults when the call is refused. Any signed-in user may read; changing the
// master still needs master_data FULL on the routes below.
router.get("/", listMasterData);
router.post("/enquiry-master/rows", masterData, validateBody(createEnquiryMasterSchema), createEnquiryMaster);
router.post("/customer-master/rows", masterData, validateBody(createCustomerMasterSchema), createCustomerMaster);
router.post("/customer-master/import", masterData, validateBody(importCustomerMasterSchema), importCustomerMaster);
router.delete("/customer-master/rows/:id", masterData, removeCustomerMaster);
router.post("/supplier-master/rows", masterData, validateBody(createSupplierMasterSchema), createSupplierMaster);
router.post("/supplier-master/import", masterData, validateBody(importSupplierMasterSchema), importSupplierMaster);
router.delete("/supplier-master/rows/:id", masterData, removeSupplierMaster);
router.post("/product-master/rows", productMaster, validateBody(productMasterSchema), createProductMaster);
router.post("/product-master/import", productMaster, validateBody(importProductMasterSchema), importProductMaster);
router.put("/product-master/rows/:id", productMaster, validateBody(productMasterSchema), editProductMaster);
router.delete("/product-master/rows/:id", productMaster, removeProductMaster);
// Literal paths must stay ahead of the "/:category" catch-alls below, or
// "editable-categories" would be parsed as a category name.
router.get("/editable-categories", masterData, listEditableCategories);

router.post("/:category", masterData, validateBody(createMasterDataValueSchema), createMasterDataValue);
router.delete("/:category/values/:value", masterData, deleteMasterDataValue);

export default router;
