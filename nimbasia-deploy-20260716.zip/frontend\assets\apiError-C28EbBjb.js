import{a as o,d as a}from"./errorMessages-Cj8NXM59.js";function t(e,s="Something went wrong."){const r=o(e,s);return a(r),console.error(e),r}export{t as l};
